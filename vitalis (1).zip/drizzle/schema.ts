import { int, mysqlEnum, mysqlTable, text, timestamp, tinyint, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const profiles = mysqlTable("profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  userRole: mysqlEnum("userRole", ["caregiver", "patient"]).default("caregiver").notNull(),
  displayName: varchar("displayName", { length: 160 }).notNull(),
  relationship: varchar("relationship", { length: 120 }),
  voiceName: varchar("voiceName", { length: 64 }).default("Luna").notNull(),
  voiceSpeed: int("voiceSpeed").default(100).notNull(),
  volume: int("volume").default(75).notNull(),
  language: varchar("language", { length: 16 }).default("pt-BR").notNull(),
  theme: mysqlEnum("theme", ["light", "dark", "system"]).default("light").notNull(),
  accentColor: varchar("accentColor", { length: 16 }).default("#7C5CFC").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const caregiverPatientLinks = mysqlTable("caregiverPatientLinks", {
  id: int("id").autoincrement().primaryKey(),
  caregiverUserId: int("caregiverUserId").notNull(),
  patientUserId: int("patientUserId").notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "revoked"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const reminders = mysqlTable("reminders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  type: mysqlEnum("type", ["medicine", "appointment", "date"]).notNull(),
  note: text("note"),
  scheduledAt: timestamp("scheduledAt").notNull(),
  recurrence: varchar("recurrence", { length: 80 }).default("once").notNull(),
  isActive: tinyint("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const emergencyContacts = mysqlTable("emergencyContacts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  relationship: varchar("relationship", { length: 120 }).notNull(),
  whatsappPhone: varchar("whatsappPhone", { length: 32 }).notNull(),
  priority: int("priority").default(1).notNull(),
  isActive: tinyint("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const alertEvents = mysqlTable("alertEvents", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  source: mysqlEnum("source", ["manual", "voice", "fall"]).notNull(),
  status: mysqlEnum("status", ["detected", "prepared", "pending_configuration", "sent", "failed"]).default("detected").notNull(),
  message: text("message").notNull(),
  recipientCount: int("recipientCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Profile = typeof profiles.$inferSelect;
export type Reminder = typeof reminders.$inferSelect;
export type EmergencyContact = typeof emergencyContacts.$inferSelect;
export type AlertEvent = typeof alertEvents.$inferSelect;
