CREATE TABLE `alertEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`source` enum('manual','voice','fall') NOT NULL,
	`status` enum('detected','prepared','pending_configuration','sent','failed') NOT NULL DEFAULT 'detected',
	`message` text NOT NULL,
	`recipientCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `alertEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `caregiverPatientLinks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`caregiverUserId` int NOT NULL,
	`patientUserId` int NOT NULL,
	`status` enum('pending','accepted','revoked') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `caregiverPatientLinks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `emergencyContacts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(160) NOT NULL,
	`relationship` varchar(120) NOT NULL,
	`whatsappPhone` varchar(32) NOT NULL,
	`priority` int NOT NULL DEFAULT 1,
	`isActive` tinyint NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `emergencyContacts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`userRole` enum('caregiver','patient') NOT NULL DEFAULT 'caregiver',
	`displayName` varchar(160) NOT NULL,
	`relationship` varchar(120),
	`voiceName` varchar(64) NOT NULL DEFAULT 'Luna',
	`voiceSpeed` int NOT NULL DEFAULT 100,
	`volume` int NOT NULL DEFAULT 75,
	`language` varchar(16) NOT NULL DEFAULT 'pt-BR',
	`theme` enum('light','dark','system') NOT NULL DEFAULT 'light',
	`accentColor` varchar(16) NOT NULL DEFAULT '#7C5CFC',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `profiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `reminders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`type` enum('medicine','appointment','date') NOT NULL,
	`note` text,
	`scheduledAt` timestamp NOT NULL,
	`recurrence` varchar(80) NOT NULL DEFAULT 'once',
	`isActive` tinyint NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `reminders_id` PRIMARY KEY(`id`)
);
