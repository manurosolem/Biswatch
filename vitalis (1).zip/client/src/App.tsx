import { Toaster, toast } from "sonner";
import { ThemeProvider } from "./contexts/ThemeContext";
import ErrorBoundary from "./components/ErrorBoundary";
import { Route, Switch, Link, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "./const";
import { trpc } from "./lib/trpc";
import {
  Activity,
  AlarmClock,
  ArrowRight,
  Bell,
  CalendarDays,
  Check,
  ChevronRight,
  CircleHelp,
  Clock3,
  HeartPulse,
  Home,
  Languages,
  LogOut,
  Menu,
  MessageCircle,
  MapPin,
  Phone,
  LocateFixed,
  Moon,
  Palette,
  Pencil,
  PhoneCall,
  Plus,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Sun,
  Trash2,
  UserRound,
  UsersRound,
  Volume2,
  Watch,
  X,
  Zap,
} from "lucide-react";
import { FormEvent, useEffect, useMemo, useState } from "react";

const LOGO_URL = "/manus-storage/async-images/Tyj8YLv9EKz93zjou5iUJ1/image-1.webp";
const PRIMARY = "#7C5CFC";

const navItems = [
  { href: "/app", label: "Visão geral", icon: Home },
  { href: "/app/lembretes", label: "Lembretes", icon: AlarmClock },
  { href: "/app/contatos", label: "Emergência", icon: UsersRound },
  { href: "/app/alertas", label: "Alertas", icon: Bell },
  { href: "/app/configuracoes", label: "Configurações", icon: Palette },
];

const reminderTypeLabels = {
  medicine: "Remédio",
  appointment: "Consulta",
  date: "Data importante",
} as const;

const alertSourceLabels = {
  manual: "Pedido manual",
  voice: "Palavra de ajuda",
  fall: "Queda / pancada",
} as const;

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`v-brand ${compact ? "v-brand--compact" : ""}`}>
      <img src={LOGO_URL} alt="" className="v-brand__mark" />
      <span className="v-brand__name">Biswatch</span>
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <Toaster position="top-right" richColors />
        <Router />
      </ThemeProvider>
    </ErrorBoundary>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/cadastro" component={SignupPage} />
      <Route path="/app/lembretes" component={DashboardPage} />
      <Route path="/app/contatos" component={DashboardPage} />
      <Route path="/app/alertas" component={DashboardPage} />
      <Route path="/app/configuracoes" component={DashboardPage} />
      <Route path="/app" component={DashboardPage} />
      <Route component={NotFoundPage} />
    </Switch>
  );
}

function HomePage() {
  const { user, loading } = useAuth();
  return (
    <div className="v-public-page">
      <header className="v-public-nav v-container">
        <Link href="/"><Logo /></Link>
        <nav className="v-public-nav__links" aria-label="Navegação principal">
          <a href="#como-funciona">Como funciona</a>
          <a href="#seguranca">Segurança</a>
          <a href="#recursos">Recursos</a>
        </nav>
        <div className="v-public-nav__actions">
          {user ? (
            <Link href="/app" className="v-button v-button--primary v-button--small">Abrir painel <ArrowRight size={16} /></Link>
          ) : (
            <>
              <Link href="/login" className="v-button v-button--ghost v-button--small">Entrar</Link>
              <Link href="/cadastro" className="v-button v-button--primary v-button--small">Criar conta</Link>
            </>
          )}
        </div>
      </header>

      <main>
        <section className="v-hero v-container">
          <div className="v-hero__copy">
            <div className="v-eyebrow"><span className="v-eyebrow__dot" /> Relógio inteligente para cuidar</div>
            <h1>Cuidado simples. <span>Segurança por perto.</span></h1>
            <p className="v-hero__lead">GPS, ligações, lembretes e ajuda em um só relógio.</p>
            <div className="v-hero__actions">
              <Link href={user ? "/app" : "/cadastro"} className="v-button v-button--primary v-button--large">Começar agora <ArrowRight size={18} /></Link>
              <a href="#como-funciona" className="v-button v-button--outline v-button--large"><CircleHelp size={18} /> Conhecer as funções</a>
            </div>
            <div className="v-trust-row"><ShieldCheck size={18} /> Login seguro para toda a família</div>
          </div>
          <div className="v-hero__visual" aria-label="Prévia do relógio inteligente Biswatch">
            <div className="v-hero__blob" />
            <div className="v-watch-card">
              <div className="v-watch-card__top"><span>Biswatch</span><span className="v-watch-card__live"><span /> conectado</span></div>
              <div className="v-watch-face"><div className="v-watch-face__time">09:41</div><div className="v-watch-face__day">terça-feira · 14 maio</div><div className="v-watch-face__pulse"><HeartPulse size={34} strokeWidth={1.6} /><span>tudo bem por aqui</span></div></div>
              <div className="v-watch-card__bottom"><span><LocateFixed size={15} /> GPS ativo</span><span><BatteryIcon /></span></div>
            </div>
            <div className="v-floating-card v-floating-card--reminder"><div className="v-icon-tile v-icon-tile--pink"><Clock3 size={18} /></div><div><strong>Próximo cuidado</strong><span>Remédio · 10:00</span></div><Check size={17} className="v-success" /></div>
            <div className="v-floating-card v-floating-card--safe"><div className="v-icon-tile v-icon-tile--green"><ShieldCheck size={18} /></div><div><strong>Contato protegido</strong><span>3 pessoas de confiança</span></div></div><div className="v-floating-card v-floating-card--location"><div className="v-icon-tile v-icon-tile--lavender"><MapPin size={18} /></div><div><strong>Localização compartilhada</strong><span>GPS disponível para a família</span></div></div>
          </div>
        </section>

        <section id="recursos" className="v-section v-section--soft">
          <div className="v-container">
            <div className="v-section-heading"><div><div className="v-eyebrow">Tudo em um só lugar</div><h2>Funções que ajudam de verdade.</h2></div><p>Fácil para usar. Útil para cuidar.</p></div>
            <div className="v-feature-grid">
              <FeatureCard icon={<MapPin />} color="lavender" title="GPS" text="Veja a localização quando precisar." />
              <FeatureCard icon={<Phone />} color="pink" title="Ligações" text="Ligue para quem quiser com poucos toques." />
              <FeatureCard icon={<AlarmClock />} color="green" title="Lembretes" text="Não esqueça remédios e consultas." />
              <FeatureCard icon={<MessageCircle />} color="lavender" title="Contatos" text="Tenha pessoas de confiança por perto." />
              <FeatureCard icon={<Volume2 />} color="pink" title="Voz" text="Escolha a voz e o idioma." />
              <FeatureCard icon={<ShieldCheck />} color="green" title="Ajuda" text="Peça socorro quando precisar." />
            </div>
          </div>
        </section>

        <section id="como-funciona" className="v-section v-container">
          <div className="v-split-section"><div className="v-steps-visual"><div className="v-step-orb"><Watch size={54} strokeWidth={1.2} /><span>01</span></div><div className="v-step-line" /><div className="v-step-orb v-step-orb--small"><Bell size={28} /><span>02</span></div><div className="v-step-line" /><div className="v-step-orb v-step-orb--small"><PhoneCall size={28} /><span>03</span></div></div><div><div className="v-eyebrow">Como funciona</div><h2>Pronto para usar.</h2><div className="v-step-list"><Step number="01" title="Crie sua conta" text="Entre no Biswatch." /><Step number="02" title="Escolha as funções" text="Configure GPS, lembretes e contatos." /><Step number="03" title="Use quando precisar" text="Ligue, peça ajuda ou veja a localização." /></div></div></div>
        </section>

        <section id="seguranca" className="v-section v-section--dark"><div className="v-container v-safety"><div><div className="v-eyebrow v-eyebrow--light">Segurança</div><h2>Ajuda para o dia a dia.</h2><p>O Biswatch registra alertas e prepara a integração com voz, queda e mensagens oficiais.</p></div><div className="v-safety__pill"><ShieldCheck size={24} /><div><strong>Proteção em primeiro lugar</strong><span>Sem promessas falsas. Tudo claro para a família.</span></div></div></div></section>
      </main>
      <footer className="v-footer v-container"><Logo compact /><span>© 2026 Biswatch. Cuidado que acompanha o tempo.</span><a className="v-footer__whatsapp" href="https://wa.me/5517996664494" target="_blank" rel="noreferrer"><MessageCircle size={20} /><span><small>Fale conosco pelo WhatsApp</small><strong>(17) 99666-4494</strong></span></a><span>Protótipo em evolução · Não substitui serviços de emergência.</span></footer>
    </div>
  );
}

function FeatureCard({ icon, title, text, color }: { icon: React.ReactNode; title: string; text: string; color: string }) {
  return <article className="v-feature-card"><div className={`v-icon-tile v-icon-tile--${color}`}>{icon}</div><h3>{title}</h3><p>{text}</p><span className="v-feature-card__arrow"><ChevronRight size={18} /></span></article>;
}

function Step({ number, title, text }: { number: string; title: string; text: string }) {
  return <div className="v-step"><span>{number}</span><div><h3>{title}</h3><p>{text}</p></div></div>;
}

function BatteryIcon() { return <span className="v-battery"><span /></span>; }

function AuthPage({ signup = false }: { signup?: boolean }) {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  useEffect(() => { if (!loading && user) setLocation("/app"); }, [loading, user, setLocation]);
  return <div className="v-auth-page"><div className="v-auth-art"><Link href="/"><Logo /></Link><div className="v-auth-art__content"><div className="v-eyebrow v-eyebrow--light">Cuidado que acompanha o tempo</div><h1>Uma rotina mais leve começa com um lembrete.</h1><p>Organize os momentos importantes e mantenha sua rede de confiança por perto.</p><div className="v-auth-art__quote"><Sparkles size={18} /><span>“O melhor cuidado é aquele que cabe na vida real.”</span></div></div><span className="v-auth-art__footer">Biswatch · protótipo funcional</span></div><div className="v-auth-form-wrap"><Link href="/" className="v-back-link">← Voltar para o início</Link><div className="v-auth-card"><div className="v-auth-card__icon"><ShieldCheck size={28} /></div><div className="v-eyebrow">{signup ? "Primeiro passo" : "Bem-vindo de volta"}</div><h2>{signup ? "Crie seu espaço de cuidado" : "Entre no seu painel"}</h2><p>{signup ? "Uma conta para organizar lembretes, contatos e preferências do Biswatch." : "Acesse sua rotina e acompanhe quem importa para você."}</p><button className="v-button v-button--primary v-button--large v-button--full" onClick={() => startLogin()} disabled={loading}>{loading ? "Verificando sessão…" : signup ? "Criar conta com login seguro" : "Entrar com login seguro"}<ArrowRight size={18} /></button><div className="v-auth-divider"><span>autenticação real</span></div><div className="v-auth-note"><ShieldCheck size={16} /><span>Você será direcionado para uma tela segura de login. O Biswatch não armazena sua senha.</span></div></div><p className="v-auth-switch">{signup ? "Já tem uma conta?" : "Ainda não tem uma conta?"} <Link href={signup ? "/login" : "/cadastro"}>{signup ? "Entrar" : "Criar conta"}</Link></p></div></div>;
}

function LoginPage() { return <AuthPage />; }
function SignupPage() { return <AuthPage signup />; }

function DashboardPage() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  useEffect(() => { if (!loading && !user) setLocation("/login"); }, [loading, user, setLocation]);
  if (loading || !user) return <LoadingScreen />;
  return <DashboardShell />;
}

function LoadingScreen() { return <div className="v-loading"><div className="v-loading__pulse"><HeartPulse size={30} /></div><p>Preparando seu espaço Biswatch…</p></div>; }

function DashboardShell() {
  const { user, logout } = useAuth({ redirectOnUnauthenticated: false });
  const [location, setLocation] = useLocation();
  const accountQuery = trpc.account.get.useQuery();
  const [mobileOpen, setMobileOpen] = useState(false);
  const profile = accountQuery.data?.profile;

  useEffect(() => {
    if (!profile) return;
    const root = document.documentElement;
    root.style.setProperty("--primary", profile.accentColor || PRIMARY);
    root.style.setProperty("--ring", profile.accentColor || PRIMARY);
    if (profile.theme === "dark" || (profile.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches)) root.classList.add("dark"); else root.classList.remove("dark");
  }, [profile]);

  const activePath = location === "/app" ? "/app" : location;
  const page = location === "/app/lembretes" ? <RemindersPage /> : location === "/app/contatos" ? <ContactsPage /> : location === "/app/alertas" ? <AlertsPage /> : location === "/app/configuracoes" ? <SettingsPage account={accountQuery.data} /> : <OverviewPage account={accountQuery.data} />;
  const userName = profile?.displayName || user?.name || "sua família";

  return <div className="v-app-shell"><aside className={`v-sidebar ${mobileOpen ? "is-open" : ""}`}><div className="v-sidebar__top"><Link href="/app" onClick={() => setMobileOpen(false)}><Logo /></Link><button className="v-icon-button v-mobile-close" onClick={() => setMobileOpen(false)} aria-label="Fechar menu"><X size={20} /></button></div><div className="v-sidebar__profile"><div className="v-avatar">{userName.slice(0, 1).toUpperCase()}</div><div><strong>{userName}</strong><span>{profile?.userRole === "patient" ? "Paciente" : "Responsável / cuidador"}</span></div></div><nav className="v-sidebar__nav" aria-label="Menu do painel">{navItems.map(item => { const Icon = item.icon; return <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)} className={`v-nav-item ${activePath === item.href ? "is-active" : ""}`}><Icon size={19} /><span>{item.label}</span>{activePath === item.href && <ChevronRight size={15} className="v-nav-item__chevron" />}</Link>; })}</nav><div className="v-sidebar__help"><div className="v-sidebar__help-icon"><HeartPulse size={18} /></div><strong>Precisa de ajuda?</strong><span>O alerta manual fica sempre disponível no painel.</span><Link href="/app/alertas" className="v-button v-button--outline v-button--small">Ver alertas <ArrowRight size={14} /></Link></div><button className="v-sidebar__logout" onClick={async () => { await logout(); setLocation("/"); }}><LogOut size={17} /> Sair da conta</button></aside>{mobileOpen && <button className="v-sidebar-overlay" aria-label="Fechar menu" onClick={() => setMobileOpen(false)} /> }<main className="v-main"><header className="v-app-header"><button className="v-icon-button v-menu-trigger" onClick={() => setMobileOpen(true)} aria-label="Abrir menu"><Menu size={21} /></button><div><span className="v-app-header__context">Seu espaço Biswatch</span><h1>{location === "/app" ? "Visão geral" : navItems.find(item => item.href === location)?.label || "Painel"}</h1></div><div className="v-app-header__actions"><span className="v-live-status"><span /> relógio conectado</span><button className="v-icon-button" onClick={() => setLocation("/app/configuracoes")} aria-label="Configurações"><Palette size={19} /></button><div className="v-avatar v-avatar--small">{userName.slice(0, 1).toUpperCase()}</div></div></header><div className="v-content">{accountQuery.isLoading ? <LoadingScreen /> : page}</div></main></div>;
}

type AccountData = {
  profile: {
    userRole: "caregiver" | "patient";
    displayName: string;
    relationship: string | null;
    voiceName: string;
    voiceSpeed: number;
    volume: number;
    language: string;
    theme: "light" | "dark" | "system";
    accentColor: string;
  };
  stats: { reminders: number; contacts: number; alerts: number };
  whatsapp: { configured: boolean; provider: string; label: string };
} | undefined;

function OverviewPage({ account }: { account: AccountData }) {
  const remindersQuery = trpc.reminders.list.useQuery();
  const contactsQuery = trpc.contacts.list.useQuery();
  const alertsQuery = trpc.alerts.list.useQuery();
  const utils = trpc.useUtils();
  const simulate = trpc.alerts.simulate.useMutation({ onSuccess: async result => { await Promise.all([utils.alerts.list.invalidate(), utils.account.get.invalidate()]); toast(result.recipientCount ? "Alerta preparado para seus contatos." : "Alerta registrado; cadastre contatos para completar o envio.", { description: "O WhatsApp só será enviado quando um provedor oficial estiver configurado." }); } });
  const reminders = remindersQuery.data ?? [];
  const nextReminders = reminders.filter(item => item.isActive === 1).slice(0, 3);
  const contacts = contactsQuery.data?.filter(item => item.isActive === 1) ?? [];
  const alerts = alertsQuery.data ?? [];
  const profile = account?.profile;
  return <div className="v-dashboard"><section className="v-welcome"><div><div className="v-eyebrow">terça-feira, 14 de maio de 2026</div><h2>Bom dia, {profile?.displayName?.split(" ")[0] || "vamos cuidar"} <span>♥</span></h2><p>Aqui está o que merece atenção hoje.</p></div><div className="v-welcome__date"><CalendarDays size={17} /><span><strong>Hoje</strong><small>{nextReminders.length} lembretes ativos</small></span></div></section><section className="v-stats-grid"><StatCard icon={<AlarmClock />} color="lavender" value={String(account?.stats.reminders ?? 0).padStart(2, "0")} label="lembretes ativos" note="na rotina" /><StatCard icon={<UsersRound />} color="pink" value={String(account?.stats.contacts ?? 0).padStart(2, "0")} label="contatos de confiança" note="cadastrados" /><StatCard icon={<ShieldCheck />} color="green" value={account?.whatsapp.configured ? "OK" : "—"} label="rede de segurança" note={account?.whatsapp.configured ? "WhatsApp conectado" : "configuração pendente"} /></section><section className="v-dashboard-grid"><div className="v-card v-card--large"><div className="v-card__heading"><div><span className="v-card__eyebrow">Hoje na rotina</span><h3>Próximos lembretes</h3></div><Link href="/app/lembretes" className="v-text-link">Ver todos <ArrowRight size={15} /></Link></div>{nextReminders.length ? <div className="v-reminder-list">{nextReminders.map(reminder => <ReminderRow key={reminder.id} reminder={reminder} />)}</div> : <EmptyState icon={<AlarmClock />} title="Nenhum lembrete ainda" text="Cadastre o primeiro remédio, consulta ou data importante." href="/app/lembretes" action="Adicionar lembrete" />}</div><div className="v-card v-card--alert"><div className="v-card__heading"><div><span className="v-card__eyebrow">Sempre disponível</span><h3>Precisa de ajuda?</h3></div><div className="v-alert-dot"><span /></div></div><p className="v-card__body-copy">Acione um alerta manual para registrar o pedido e preparar a mensagem para seus contatos de confiança.</p><button className="v-alert-action" onClick={() => simulate.mutate({ source: "manual" })} disabled={simulate.isPending}><PhoneCall size={23} /><span>{simulate.isPending ? "Registrando alerta…" : "Simular pedido de ajuda"}</span><ArrowRight size={18} /></button><div className="v-alert-footnote"><ShieldCheck size={15} /> {contacts.length ? `${contacts.length} contatos ativos serão considerados` : "Cadastre contatos para completar a rede"}</div></div></section><section className="v-dashboard-grid v-dashboard-grid--bottom"><div className="v-card"><div className="v-card__heading"><div><span className="v-card__eyebrow">Rede de confiança</span><h3>Contatos de emergência</h3></div><Link href="/app/contatos" className="v-icon-button" aria-label="Ver contatos"><ArrowRight size={17} /></Link></div>{contacts.length ? <div className="v-contact-mini-list">{contacts.slice(0, 3).map(contact => <div key={contact.id} className="v-contact-mini"><div className="v-avatar v-avatar--pink">{contact.name.slice(0, 1).toUpperCase()}</div><div><strong>{contact.name}</strong><span>{contact.relationship} · {contact.whatsappPhone}</span></div><span className="v-priority">P{contact.priority}</span></div>)}</div> : <EmptyState icon={<UsersRound />} title="Sua rede ainda está vazia" text="Adicione alguém de confiança para receber alertas." href="/app/contatos" action="Cadastrar contato" />}</div><div className="v-card"><div className="v-card__heading"><div><span className="v-card__eyebrow">Atividade recente</span><h3>Últimos alertas</h3></div><Link href="/app/alertas" className="v-icon-button" aria-label="Ver alertas"><ArrowRight size={17} /></Link></div>{alerts.length ? <div className="v-alert-mini-list">{alerts.slice(0, 3).map(alert => <div key={alert.id} className="v-alert-mini"><div className="v-alert-mini__icon"><Bell size={16} /></div><div><strong>{alertSourceLabels[alert.source]}</strong><span>{formatDateTime(alert.createdAt)}</span></div><StatusBadge status={alert.status} /></div>)}</div> : <EmptyState icon={<Bell />} title="Sem alertas registrados" text="Quando algo acontecer, aparecerá aqui." />}</div></section></div>;
}

function StatCard({ icon, value, label, note, color }: { icon: React.ReactNode; value: string; label: string; note: string; color: string }) { return <div className="v-stat-card"><div className={`v-icon-tile v-icon-tile--${color}`}>{icon}</div><div><strong>{value}</strong><span>{label}</span><small>{note}</small></div></div>; }
function ReminderRow({ reminder }: { reminder: any }) { return <div className="v-reminder-row"><div className={`v-reminder-row__icon v-reminder-row__icon--${reminder.type}`}><ReminderIcon type={reminder.type} /></div><div className="v-reminder-row__main"><strong>{reminder.title}</strong><span>{reminder.note || reminderTypeLabels[reminder.type as keyof typeof reminderTypeLabels]}</span></div><div className="v-reminder-row__time"><strong>{formatTime(reminder.scheduledAt)}</strong><span>{reminder.recurrence === "once" ? "hoje" : reminder.recurrence}</span></div></div>; }
function ReminderIcon({ type }: { type: string }) { return type === "medicine" ? <Activity size={18} /> : type === "appointment" ? <CalendarDays size={18} /> : <Sparkles size={18} />; }
function EmptyState({ icon, title, text, href, action }: { icon: React.ReactNode; title: string; text: string; href?: string; action?: string }) { return <div className="v-empty"><div className="v-empty__icon">{icon}</div><strong>{title}</strong><p>{text}</p>{href && action && <Link href={href} className="v-button v-button--outline v-button--small">{action} <Plus size={15} /></Link>}</div>; }

function RemindersPage() {
  const query = trpc.reminders.list.useQuery();
  const utils = trpc.useUtils();
  const create = trpc.reminders.create.useMutation({ onSuccess: async () => { await Promise.all([utils.reminders.list.invalidate(), utils.account.get.invalidate()]); toast.success("Lembrete salvo na rotina."); resetForm(); } });
  const update = trpc.reminders.update.useMutation({ onSuccess: async () => { await Promise.all([utils.reminders.list.invalidate(), utils.account.get.invalidate()]); toast.success("Lembrete atualizado."); resetForm(); } });
  const toggle = trpc.reminders.toggle.useMutation({ onSuccess: () => utils.reminders.list.invalidate() });
  const remove = trpc.reminders.remove.useMutation({ onSuccess: async () => { await Promise.all([utils.reminders.list.invalidate(), utils.account.get.invalidate()]); toast.success("Lembrete removido."); } });
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({ title: "", type: "medicine" as "medicine" | "appointment" | "date", scheduledAt: "", recurrence: "once", note: "" });
  const resetForm = () => { setForm({ title: "", type: "medicine", scheduledAt: "", recurrence: "once", note: "" }); setEditingId(null); setShowForm(false); };
  const submit = (event: FormEvent) => { event.preventDefault(); if (!form.scheduledAt) return toast.error("Escolha uma data e horário."); const payload = { ...form, note: form.note || null, scheduledAt: new Date(form.scheduledAt).toISOString() }; if (editingId) update.mutate({ id: editingId, ...payload }); else create.mutate(payload); };
  const reminders = query.data ?? [];
  return <div className="v-page"><PageIntro eyebrow="Rotina tranquila" title="Lembretes" text="Organize os momentos importantes do dia com clareza e carinho." action={<button className="v-button v-button--primary" onClick={() => setShowForm(true)}><Plus size={18} /> Novo lembrete</button>} /><div className="v-filter-row"><span className="v-filter-label">{reminders.length} itens na sua rotina</span><span className="v-soft-chip"><AlarmClock size={15} /> horários locais</span></div>{showForm && <form className="v-card v-form-card" onSubmit={submit}><div className="v-card__heading"><div><span className="v-card__eyebrow">{editingId ? "Ajustar cuidado" : "Novo cuidado"}</span><h3>{editingId ? "Editar lembrete" : "Adicionar lembrete"}</h3></div><button type="button" className="v-icon-button" onClick={resetForm}><X size={18} /></button></div><div className="v-form-grid"><Field label="O que precisa ser lembrado?"><input autoFocus value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="Ex.: Tomar remédio da manhã" required /></Field><Field label="Tipo"><select value={form.type} onChange={e => setForm({ ...form, type: e.target.value as typeof form.type })}><option value="medicine">Remédio</option><option value="appointment">Consulta</option><option value="date">Data importante</option></select></Field><Field label="Data e hora"><input type="datetime-local" value={form.scheduledAt} onChange={e => setForm({ ...form, scheduledAt: e.target.value })} required /></Field><Field label="Repetição"><select value={form.recurrence} onChange={e => setForm({ ...form, recurrence: e.target.value })}><option value="once">Uma vez</option><option value="diário">Todos os dias</option><option value="semanal">Toda semana</option></select></Field><Field label="Observação" wide><textarea value={form.note} onChange={e => setForm({ ...form, note: e.target.value })} placeholder="Ex.: depois do café da manhã" rows={3} /></Field></div><div className="v-form-actions"><button type="button" className="v-button v-button--ghost" onClick={resetForm}>Cancelar</button><button className="v-button v-button--primary" disabled={create.isPending}>{create.isPending || update.isPending ? "Salvando…" : editingId ? "Atualizar lembrete" : "Salvar lembrete"} <Check size={17} /></button></div></form>}<div className="v-list-stack">{reminders.length ? reminders.map(reminder => <div className={`v-list-card ${reminder.isActive === 0 ? "is-inactive" : ""}`} key={reminder.id}><div className={`v-reminder-row__icon v-reminder-row__icon--${reminder.type}`}><ReminderIcon type={reminder.type} /></div><div className="v-list-card__content"><div className="v-list-card__title"><strong>{reminder.title}</strong><span className={`v-type-label v-type-label--${reminder.type}`}>{reminderTypeLabels[reminder.type as keyof typeof reminderTypeLabels]}</span></div><p>{reminder.note || "Sem observações adicionais"}</p><div className="v-list-card__meta"><span><Clock3 size={14} /> {formatDateTime(reminder.scheduledAt)}</span><span><AlarmClock size={14} /> {reminder.recurrence === "once" ? "Uma vez" : reminder.recurrence}</span></div></div><div className="v-list-card__actions"><button className="v-icon-button" onClick={() => { setEditingId(reminder.id); setForm({ title: reminder.title, type: reminder.type, scheduledAt: toDateTimeLocal(reminder.scheduledAt), recurrence: reminder.recurrence, note: reminder.note || "" }); setShowForm(true); }} aria-label="Editar lembrete"><Pencil size={17} /></button><button className={`v-switch ${reminder.isActive ? "is-on" : ""}`} onClick={() => toggle.mutate({ id: reminder.id })} aria-label={reminder.isActive ? "Desativar lembrete" : "Ativar lembrete"}><span /></button><button className="v-icon-button" onClick={() => remove.mutate({ id: reminder.id })} aria-label="Remover lembrete"><Trash2 size={17} /></button></div></div>) : <div className="v-card"><EmptyState icon={<AlarmClock />} title="Comece pela sua rotina" text="Adicione remédios, consultas e datas importantes para ver tudo organizado aqui." action="Adicionar lembrete" href="/app/lembretes" /></div>}</div></div>;
}

function ContactsPage() {
  const query = trpc.contacts.list.useQuery();
  const utils = trpc.useUtils();
  const create = trpc.contacts.create.useMutation({ onSuccess: async () => { await Promise.all([utils.contacts.list.invalidate(), utils.account.get.invalidate()]); toast.success("Contato de confiança salvo."); resetForm(); } });
  const update = trpc.contacts.update.useMutation({ onSuccess: async () => { await Promise.all([utils.contacts.list.invalidate(), utils.account.get.invalidate()]); toast.success("Contato atualizado."); resetForm(); } });
  const toggle = trpc.contacts.toggle.useMutation({ onSuccess: () => utils.contacts.list.invalidate() });
  const remove = trpc.contacts.remove.useMutation({ onSuccess: async () => { await Promise.all([utils.contacts.list.invalidate(), utils.account.get.invalidate()]); toast.success("Contato removido."); } });
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({ name: "", relationship: "", whatsappPhone: "", priority: 1 });
  const resetForm = () => { setForm({ name: "", relationship: "", whatsappPhone: "", priority: 1 }); setEditingId(null); setShowForm(false); };
  const submit = (event: FormEvent) => { event.preventDefault(); if (editingId) update.mutate({ id: editingId, ...form }); else create.mutate(form); };
  const contacts = query.data ?? [];
  return <div className="v-page"><PageIntro eyebrow="Rede de confiança" title="Contatos de emergência" text="Pessoas que podem receber um pedido de ajuda quando você precisar." action={<button className="v-button v-button--primary" onClick={() => setShowForm(true)}><Plus size={18} /> Novo contato</button>} /><div className="v-info-banner"><div className="v-info-banner__icon"><MessageCircle size={19} /></div><div><strong>WhatsApp preparado, envio transparente</strong><span>O Biswatch só considera um alerta enviado após a confirmação de um provedor oficial configurado.</span></div><Link href="/app/configuracoes" className="v-text-link">Configurar <ArrowRight size={15} /></Link></div>{showForm && <form className="v-card v-form-card" onSubmit={submit}><div className="v-card__heading"><div><span className="v-card__eyebrow">{editingId ? "Ajustar pessoa" : "Nova pessoa de confiança"}</span><h3>{editingId ? "Editar contato" : "Cadastrar contato"}</h3></div><button type="button" className="v-icon-button" onClick={resetForm}><X size={18} /></button></div><div className="v-form-grid"><Field label="Nome completo"><input autoFocus value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Ex.: Maria da Silva" required /></Field><Field label="Relação"><input value={form.relationship} onChange={e => setForm({ ...form, relationship: e.target.value })} placeholder="Ex.: filha, cuidador" required /></Field><Field label="WhatsApp com DDI"><input value={form.whatsappPhone} onChange={e => setForm({ ...form, whatsappPhone: e.target.value })} placeholder="Ex.: +55 11 99999-9999" required /></Field><Field label="Prioridade"><select value={form.priority} onChange={e => setForm({ ...form, priority: Number(e.target.value) })}><option value={1}>1 · Primeiro contato</option><option value={2}>2 · Segundo contato</option><option value={3}>3 · Terceiro contato</option></select></Field></div><div className="v-form-actions"><button type="button" className="v-button v-button--ghost" onClick={resetForm}>Cancelar</button><button className="v-button v-button--primary" disabled={create.isPending}>{create.isPending || update.isPending ? "Salvando…" : editingId ? "Atualizar contato" : "Salvar contato"} <Check size={17} /></button></div></form>}<div className="v-contact-grid">{contacts.length ? contacts.map(contact => <article className={`v-contact-card ${contact.isActive === 0 ? "is-inactive" : ""}`} key={contact.id}><div className="v-contact-card__top"><div className="v-avatar v-avatar--pink v-avatar--large">{contact.name.slice(0, 1).toUpperCase()}</div><span className="v-priority">Prioridade {contact.priority}</span></div><h3>{contact.name}</h3><p>{contact.relationship}</p><div className="v-contact-card__phone"><MessageCircle size={16} /> {contact.whatsappPhone}</div><div className="v-contact-card__footer"><span className={`v-active-label ${contact.isActive ? "is-active" : ""}`}><span /> {contact.isActive ? "Ativo para alertas" : "Pausado"}</span><div><button className="v-icon-button" onClick={() => { setEditingId(contact.id); setForm({ name: contact.name, relationship: contact.relationship, whatsappPhone: contact.whatsappPhone, priority: contact.priority }); setShowForm(true); }} aria-label="Editar contato"><Pencil size={16} /></button><button className="v-icon-button" onClick={() => toggle.mutate({ id: contact.id })} aria-label="Alternar contato">{contact.isActive ? <Bell size={16} /> : <Bell size={16} />}</button><button className="v-icon-button" onClick={() => remove.mutate({ id: contact.id })} aria-label="Remover contato"><Trash2 size={16} /></button></div></div></article>) : <div className="v-card v-contact-empty"><EmptyState icon={<UsersRound />} title="Cadastre sua primeira pessoa de confiança" text="Ela ficará pronta para receber um alerta quando o provedor de mensagens for configurado." action="Adicionar contato" href="/app/contatos" /></div>}</div></div>;
}

function AlertsPage() {
  const query = trpc.alerts.list.useQuery();
  const utils = trpc.useUtils();
  const simulate = trpc.alerts.simulate.useMutation({ onSuccess: async result => { await Promise.all([utils.alerts.list.invalidate(), utils.account.get.invalidate()]); toast("Alerta registrado", { description: result.whatsapp.configured ? "O provedor está pronto para uma integração de envio." : "Configure um provedor oficial antes de enviar mensagens reais." }); } });
  const alerts = query.data ?? [];
  return <div className="v-page"><PageIntro eyebrow="Central de segurança" title="Alertas" text="Acompanhe eventos e teste o fluxo de ajuda com transparência." /><div className="v-alert-simulator v-card"><div><div className="v-card__eyebrow">Demonstração segura</div><h3>Qual evento você quer simular?</h3><p>Esta versão registra o evento no histórico. O relógio físico e o envio real de WhatsApp serão conectados em uma próxima etapa.</p></div><div className="v-alert-simulator__actions"><button className="v-simulate-button v-simulate-button--pink" onClick={() => simulate.mutate({ source: "voice" })} disabled={simulate.isPending}><Volume2 size={19} /><span><strong>“Ajuda” ou “socorro”</strong><small>detecção de voz</small></span></button><button className="v-simulate-button v-simulate-button--lavender" onClick={() => simulate.mutate({ source: "fall" })} disabled={simulate.isPending}><Activity size={19} /><span><strong>Queda / pancada</strong><small>sensor do relógio</small></span></button></div></div><div className="v-alert-timeline"><div className="v-section-heading v-section-heading--compact"><div><div className="v-eyebrow">Histórico</div><h3>Eventos recentes</h3></div><span className="v-soft-chip"><ShieldCheck size={15} /> {alerts.length} registrados</span></div>{alerts.length ? alerts.map(alert => <div className="v-alert-row" key={alert.id}><div className="v-alert-row__source"><div className={`v-alert-row__icon v-alert-row__icon--${alert.source}`}><AlertSourceIcon source={alert.source} /></div><div><strong>{alertSourceLabels[alert.source]}</strong><span>{alert.message}</span></div></div><div className="v-alert-row__meta"><span>{formatDateTime(alert.createdAt)}</span><StatusBadge status={alert.status} /></div></div>) : <div className="v-card"><EmptyState icon={<Bell />} title="Nenhum evento ainda" text="Use uma das simulações acima para acompanhar o fluxo." /></div>}</div></div>;
}
function AlertSourceIcon({ source }: { source: string }) { return source === "voice" ? <Volume2 size={17} /> : source === "fall" ? <Activity size={17} /> : <PhoneCall size={17} />; }
function StatusBadge({ status }: { status: string }) { const labels: Record<string, string> = { pending_configuration: "configuração pendente", detected: "detectado", prepared: "preparado", sent: "enviado", failed: "falhou" }; return <span className={`v-status-badge v-status-badge--${status}`}><span /> {labels[status] || status}</span>; }

function SettingsPage({ account }: { account: AccountData }) {
  const utils = trpc.useUtils();
  const update = trpc.account.update.useMutation({ onSuccess: async profile => { await utils.account.get.invalidate(); applyAppearance(profile.theme, profile.accentColor); toast.success("Preferências atualizadas."); } });
  const profile = account?.profile;
  const [form, setForm] = useState({ userRole: "caregiver" as "caregiver" | "patient", displayName: "", relationship: "", voiceName: "Luna", voiceSpeed: 100, volume: 75, language: "pt-BR" as "pt-BR" | "en-US" | "es-ES", theme: "light" as "light" | "dark" | "system", accentColor: PRIMARY });
  useEffect(() => { if (profile) setForm({ userRole: profile.userRole, displayName: profile.displayName, relationship: profile.relationship || "", voiceName: profile.voiceName, voiceSpeed: profile.voiceSpeed, volume: profile.volume, language: profile.language as typeof form.language, theme: profile.theme, accentColor: profile.accentColor }); }, [profile]);
  if (!profile) return null;
  const submit = (event: FormEvent) => { event.preventDefault(); update.mutate(form); };
  return <div className="v-page"><PageIntro eyebrow="Seu jeito de cuidar" title="Configurações" text="Ajuste o Biswatch para combinar com a rotina e a voz de cada pessoa." /><form onSubmit={submit} className="v-settings-grid"><section className="v-card v-settings-section"><div className="v-settings-section__heading"><div className="v-icon-tile v-icon-tile--lavender"><UserRound size={19} /></div><div><h3>Perfil de cuidado</h3><p>Estas informações ajudam a adaptar o painel.</p></div></div><div className="v-form-grid"><Field label="Como você usa o Biswatch?"><select value={form.userRole} onChange={e => setForm({ ...form, userRole: e.target.value as typeof form.userRole })}><option value="caregiver">Sou responsável / cuidador</option><option value="patient">Sou paciente</option></select></Field><Field label="Nome exibido"><input value={form.displayName} onChange={e => setForm({ ...form, displayName: e.target.value })} /></Field><Field label="Relação com o paciente" wide><input value={form.relationship} onChange={e => setForm({ ...form, relationship: e.target.value })} placeholder="Ex.: filha, cuidador profissional" /></Field></div></section><section className="v-card v-settings-section"><div className="v-settings-section__heading"><div className="v-icon-tile v-icon-tile--pink"><Volume2 size={19} /></div><div><h3>Voz da IA</h3><p>Deixe os lembretes mais naturais para quem vai ouvir.</p></div></div><div className="v-form-grid"><Field label="Voz"><select value={form.voiceName} onChange={e => setForm({ ...form, voiceName: e.target.value })}><option>Luna</option><option>Clara</option><option>Helena</option></select></Field><Field label="Idioma"><select value={form.language} onChange={e => setForm({ ...form, language: e.target.value as typeof form.language })}><option value="pt-BR">Português (Brasil)</option><option value="en-US">English (US)</option><option value="es-ES">Español</option></select></Field><Field label={`Velocidade · ${form.voiceSpeed}%`} wide><input className="v-range" type="range" min="60" max="140" value={form.voiceSpeed} onChange={e => setForm({ ...form, voiceSpeed: Number(e.target.value) })} /></Field><Field label={`Volume · ${form.volume}%`} wide><input className="v-range" type="range" min="0" max="100" value={form.volume} onChange={e => setForm({ ...form, volume: Number(e.target.value) })} /></Field></div></section><section className="v-card v-settings-section"><div className="v-settings-section__heading"><div className="v-icon-tile v-icon-tile--green"><Palette size={19} /></div><div><h3>Aparência</h3><p>Escolha a forma mais confortável de visualizar o painel.</p></div></div><div className="v-theme-options">{(["light", "dark", "system"] as const).map(theme => <button type="button" key={theme} className={`v-theme-option ${form.theme === theme ? "is-selected" : ""}`} onClick={() => { setForm({ ...form, theme }); applyAppearance(theme, form.accentColor); }}><div className={`v-theme-option__preview v-theme-option__preview--${theme}`}>{theme === "light" ? <Sun size={18} /> : theme === "dark" ? <Moon size={18} /> : <Smartphone size={18} />}</div><span>{theme === "light" ? "Claro" : theme === "dark" ? "Escuro" : "Sistema"}</span>{form.theme === theme && <Check size={15} />}</button>)}</div><div className="v-color-row"><div><strong>Cor de destaque</strong><span>Você pode personalizar o roxo Biswatch.</span></div><div className="v-color-picker"><input type="color" value={form.accentColor} onChange={e => { setForm({ ...form, accentColor: e.target.value }); document.documentElement.style.setProperty("--primary", e.target.value); }} /><code>{form.accentColor}</code></div></div></section><section className="v-card v-settings-section v-settings-section--whatsapp"><div className="v-settings-section__heading"><div className="v-icon-tile v-icon-tile--pink"><MessageCircle size={19} /></div><div><h3>Mensagens de emergência</h3><p>O canal de envio é configurado no servidor para proteger suas credenciais.</p></div><span className={`v-connection-badge ${account?.whatsapp.configured ? "is-connected" : ""}`}><span /> {account?.whatsapp.configured ? "Conectado" : "Pendente"}</span></div><div className="v-whatsapp-note"><ShieldCheck size={17} /><span>{account?.whatsapp.label}. Nunca coloque tokens no GitHub ou no navegador.</span></div></section><div className="v-settings-submit"><span><ShieldCheck size={16} /> Suas preferências ficam associadas à sua conta.</span><button className="v-button v-button--primary v-button--large" disabled={update.isPending}>{update.isPending ? "Salvando…" : "Salvar preferências"} <Check size={18} /></button></div></form></div>;
}

function Field({ label, children, wide = false }: { label: string; children: React.ReactNode; wide?: boolean }) { return <label className={`v-field ${wide ? "v-field--wide" : ""}`}><span>{label}</span>{children}</label>; }
function PageIntro({ eyebrow, title, text, action }: { eyebrow: string; title: string; text: string; action?: React.ReactNode }) { return <div className="v-page-intro"><div><div className="v-eyebrow">{eyebrow}</div><h2>{title}</h2><p>{text}</p></div>{action && <div>{action}</div>}</div>; }
function toDateTimeLocal(value: Date | string) { const date = new Date(value); const pad = (part: number) => String(part).padStart(2, "0"); return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`; }
function formatTime(value: Date | string) { return new Intl.DateTimeFormat("pt-BR", { hour: "2-digit", minute: "2-digit" }).format(new Date(value)); }
function formatDateTime(value: Date | string) { return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(value)).replace(" de ", " "); }
function applyAppearance(theme: "light" | "dark" | "system", accent: string) { const root = document.documentElement; root.style.setProperty("--primary", accent || PRIMARY); if (theme === "dark" || (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches)) root.classList.add("dark"); else root.classList.remove("dark"); }
function NotFoundPage() { return <div className="v-loading"><Logo /><h1>Página não encontrada</h1><Link href="/" className="v-button v-button--primary">Voltar ao início</Link></div>; }

export default App;
