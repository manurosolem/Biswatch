# Direção visual — Biswatch

## Movimento e princípios

Biswatch será uma interface de cuidado calmo: clara, acolhedora e confiante sem parecer infantil. O visual combina a precisão de um relógio com o conforto de um cuidado próximo. A prioridade é legibilidade para pessoas idosas, com ações grandes, contraste consistente e pouca distração.

## Cor e layout

A página clara usa branco e rosa como cores predominantes. O modo escuro usa preto e roxo, com rosa apenas nos pontos de atenção. O layout é um painel responsivo com navegação lateral em desktop e atalhos em telas menores. Cartões arredondados agrupam resumos e ações, com o alerta sempre acessível.

## Elementos assinatura

O símbolo Biswatch une um mostrador de relógio simplificado a uma linha de pulso em forma de coração/escudo, representando tempo, presença e proteção. Indicadores de status usam pontos e textos, nunca apenas cor. Alertas têm uma trilha visual de detecção, preparo e envio.

## Interação e movimento

Interações são modernas, suaves e rápidas: entrada de cartões por leve deslocamento, relógio flutuando de forma discreta, estados de foco visíveis e confirmação de ações por mensagem contextual. A animação respeita `prefers-reduced-motion` e nunca deve atrapalhar a leitura.

## Tipografia e voz

Usar uma família sem serifa legível, com títulos fortes e corpo confortável. A voz da marca é humana, clara e protetora: frases curtas, sem jargão e sem prometer atendimento emergencial quando houver apenas simulação.

## Marca

Nome: Biswatch.

Essência: “cuidado que acompanha o tempo”.

Cor assinatura no tema claro: rosa Biswatch `#E05291` sobre branco. No tema escuro: roxo `#A78BFA` sobre preto `#0B0710`, com rosa cuidado `#F08BBD` como apoio.

Logo: símbolo próprio, com fundo cheio, formas sólidas e silhueta legível em 24–48 px; será reutilizado no cabeçalho e favicon.
