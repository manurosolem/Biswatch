import { eq } from "drizzle-orm";
import { z } from "zod";
import { alertEvents, emergencyContacts, reminders } from "../drizzle/schema";
import { getWhatsAppStatus } from "./integrations/whatsapp";
import * as db from "./db";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

const idInput = z.object({ id: z.number().int().positive() });
const roleInput = z.enum(["caregiver", "patient"]);
const reminderType = z.enum(["medicine", "appointment", "date"]);
const alertSource = z.enum(["manual", "voice", "fall"]);

function requireDbUserId(userId: number) {
  if (!Number.isInteger(userId) || userId < 1) throw new Error("Invalid user id");
  return userId;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  account: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const userId = requireDbUserId(ctx.user.id);
      const profile = await db.getOrCreateProfile(userId, ctx.user.name);
      const [reminderRows, contactRows, alertRows] = await Promise.all([
        db.listReminders(userId),
        db.listContacts(userId),
        db.listAlerts(userId),
      ]);
      return {
        user: ctx.user,
        profile,
        stats: {
          reminders: reminderRows.filter(item => item.isActive === 1).length,
          contacts: contactRows.filter(item => item.isActive === 1).length,
          alerts: alertRows.length,
        },
        whatsapp: getWhatsAppStatus(),
      };
    }),
    update: protectedProcedure
      .input(
        z.object({
          userRole: roleInput.optional(),
          displayName: z.string().trim().min(2).max(160).optional(),
          relationship: z.string().trim().max(120).optional().nullable(),
          voiceName: z.string().trim().min(2).max(64).optional(),
          voiceSpeed: z.number().int().min(60).max(140).optional(),
          volume: z.number().int().min(0).max(100).optional(),
          language: z.enum(["pt-BR", "en-US", "es-ES"]).optional(),
          theme: z.enum(["light", "dark", "system"]).optional(),
          accentColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        return db.updateProfile(requireDbUserId(ctx.user.id), input);
      }),
  }),

  reminders: router({
    list: protectedProcedure.query(({ ctx }) => db.listReminders(requireDbUserId(ctx.user.id))),
    create: protectedProcedure
      .input(
        z.object({
          title: z.string().trim().min(2).max(180),
          type: reminderType,
          note: z.string().trim().max(1000).optional().nullable(),
          scheduledAt: z.string().datetime(),
          recurrence: z.string().trim().min(2).max(80).default("once"),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        const database = await db.getDb();
        if (!database) throw new Error("Database is not available");
        await database.insert(reminders).values({
          userId: requireDbUserId(ctx.user.id),
          title: input.title,
          type: input.type,
          note: input.note ?? null,
          scheduledAt: new Date(input.scheduledAt),
          recurrence: input.recurrence,
        });
        return { success: true } as const;
      }),
    update: protectedProcedure
      .input(
        idInput.extend({
          title: z.string().trim().min(2).max(180),
          type: reminderType,
          note: z.string().trim().max(1000).optional().nullable(),
          scheduledAt: z.string().datetime(),
          recurrence: z.string().trim().min(2).max(80),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        const current = await db.getReminder(requireDbUserId(ctx.user.id), input.id);
        if (!current) throw new Error("Reminder not found");
        const database = await db.getDb();
        if (!database) throw new Error("Database is not available");
        await database.update(reminders).set({
          title: input.title,
          type: input.type,
          note: input.note ?? null,
          scheduledAt: new Date(input.scheduledAt),
          recurrence: input.recurrence,
        }).where(eq(reminders.id, input.id));
        return { success: true } as const;
      }),
    toggle: protectedProcedure.input(idInput).mutation(async ({ ctx, input }) => {
      const current = await db.getReminder(requireDbUserId(ctx.user.id), input.id);
      if (!current) throw new Error("Reminder not found");
      const database = await db.getDb();
      if (!database) throw new Error("Database is not available");
      await database.update(reminders).set({ isActive: current.isActive === 1 ? 0 : 1 }).where(eq(reminders.id, input.id));
      return { success: true } as const;
    }),
    remove: protectedProcedure.input(idInput).mutation(async ({ ctx, input }) => {
      const current = await db.getReminder(requireDbUserId(ctx.user.id), input.id);
      if (!current) throw new Error("Reminder not found");
      const database = await db.getDb();
      if (!database) throw new Error("Database is not available");
      await database.delete(reminders).where(eq(reminders.id, input.id));
      return { success: true } as const;
    }),
  }),

  contacts: router({
    list: protectedProcedure.query(({ ctx }) => db.listContacts(requireDbUserId(ctx.user.id))),
    create: protectedProcedure
      .input(
        z.object({
          name: z.string().trim().min(2).max(160),
          relationship: z.string().trim().min(2).max(120),
          whatsappPhone: z.string().trim().min(8).max(32),
          priority: z.number().int().min(1).max(10).default(1),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        const database = await db.getDb();
        if (!database) throw new Error("Database is not available");
        await database.insert(emergencyContacts).values({ userId: requireDbUserId(ctx.user.id), ...input });
        return { success: true } as const;
      }),
    update: protectedProcedure
      .input(
        idInput.extend({
          name: z.string().trim().min(2).max(160),
          relationship: z.string().trim().min(2).max(120),
          whatsappPhone: z.string().trim().min(8).max(32),
          priority: z.number().int().min(1).max(10),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        const current = await db.getContact(requireDbUserId(ctx.user.id), input.id);
        if (!current) throw new Error("Contact not found");
        const database = await db.getDb();
        if (!database) throw new Error("Database is not available");
        await database.update(emergencyContacts).set({
          name: input.name,
          relationship: input.relationship,
          whatsappPhone: input.whatsappPhone,
          priority: input.priority,
        }).where(eq(emergencyContacts.id, input.id));
        return { success: true } as const;
      }),
    toggle: protectedProcedure.input(idInput).mutation(async ({ ctx, input }) => {
      const current = await db.getContact(requireDbUserId(ctx.user.id), input.id);
      if (!current) throw new Error("Contact not found");
      const database = await db.getDb();
      if (!database) throw new Error("Database is not available");
      await database.update(emergencyContacts).set({ isActive: current.isActive === 1 ? 0 : 1 }).where(eq(emergencyContacts.id, input.id));
      return { success: true } as const;
    }),
    remove: protectedProcedure.input(idInput).mutation(async ({ ctx, input }) => {
      const current = await db.getContact(requireDbUserId(ctx.user.id), input.id);
      if (!current) throw new Error("Contact not found");
      const database = await db.getDb();
      if (!database) throw new Error("Database is not available");
      await database.delete(emergencyContacts).where(eq(emergencyContacts.id, input.id));
      return { success: true } as const;
    }),
  }),

  alerts: router({
    list: protectedProcedure.query(({ ctx }) => db.listAlerts(requireDbUserId(ctx.user.id))),
    simulate: protectedProcedure
      .input(z.object({ source: alertSource }))
      .mutation(async ({ ctx, input }) => {
        const userId = requireDbUserId(ctx.user.id);
        const contacts = await db.listContacts(userId);
        const activeContacts = contacts.filter(contact => contact.isActive === 1);
        const messageBySource = {
          manual: "Pedido de ajuda acionado pelo painel Vitalis.",
          voice: "A palavra de ajuda foi identificada pelo protótipo de voz.",
          fall: "Uma possível queda/pancada foi identificada pelo protótipo do relógio.",
        } as const;
        const database = await db.getDb();
        if (!database) throw new Error("Database is not available");
        await database.insert(alertEvents).values({
          userId,
          source: input.source,
          status: "pending_configuration",
          message: messageBySource[input.source],
          recipientCount: activeContacts.length,
        });
        return {
          status: "pending_configuration" as const,
          recipientCount: activeContacts.length,
          message: messageBySource[input.source],
          whatsapp: getWhatsAppStatus(),
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
