export type WhatsAppStatus = {
  configured: boolean;
  provider: "webhook" | "none";
  label: string;
};

export function getWhatsAppStatus(): WhatsAppStatus {
  const configured = Boolean(process.env.WHATSAPP_WEBHOOK_URL && process.env.WHATSAPP_API_TOKEN);
  return configured
    ? { configured: true, provider: "webhook", label: "Integração pronta para o provedor configurado" }
    : { configured: false, provider: "none", label: "Configure um provedor oficial para ativar o envio" };
}

/**
 * This adapter intentionally does not send messages during simulated alerts.
 * A future device/webhook flow can call this function after explicit provider
 * configuration and should only mark an alert as sent after a 2xx response.
 */
export async function sendWhatsAppMessage(to: string, message: string) {
  const webhookUrl = process.env.WHATSAPP_WEBHOOK_URL;
  const token = process.env.WHATSAPP_API_TOKEN;
  if (!webhookUrl || !token) return { sent: false, reason: "pending_configuration" as const };

  const response = await fetch(webhookUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ to, message }),
  });

  return response.ok
    ? { sent: true as const }
    : { sent: false as const, reason: "provider_error" as const };
}
