import { and, asc, desc, eq, inArray, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  alertEvents,
  caregiverPatientLinks,
  emergencyContacts,
  profiles,
  reminders,
  type InsertUser,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];

  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getOrCreateProfile(userId: number, fallbackName: string | null) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db.select().from(profiles).where(eq(profiles.userId, userId)).limit(1);
  if (existing[0]) return existing[0];
  await db.insert(profiles).values({
    userId,
    displayName: fallbackName?.trim() || "Minha conta",
  });
  const created = await db.select().from(profiles).where(eq(profiles.userId, userId)).limit(1);
  if (!created[0]) throw new Error("Profile could not be created");
  return created[0];
}

export async function updateProfile(userId: number, values: Partial<typeof profiles.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(profiles).set(values).where(eq(profiles.userId, userId));
  return getOrCreateProfile(userId, null);
}

export async function getAccessibleUserIds(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const linked = await db
    .select()
    .from(caregiverPatientLinks)
    .where(
      and(
        eq(caregiverPatientLinks.status, "accepted"),
        or(
          eq(caregiverPatientLinks.caregiverUserId, userId),
          eq(caregiverPatientLinks.patientUserId, userId),
        ),
      ),
    );
  const ids = new Set<number>([userId]);
  linked.forEach(link => {
    ids.add(link.caregiverUserId);
    ids.add(link.patientUserId);
  });
  return [...ids];
}

export async function listReminders(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const ids = await getAccessibleUserIds(userId);
  return db.select().from(reminders).where(inArray(reminders.userId, ids)).orderBy(asc(reminders.scheduledAt));
}

export async function getReminder(userId: number, id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const ids = await getAccessibleUserIds(userId);
  const result = await db.select().from(reminders).where(and(eq(reminders.id, id), inArray(reminders.userId, ids))).limit(1);
  return result[0];
}

export async function listContacts(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const ids = await getAccessibleUserIds(userId);
  return db.select().from(emergencyContacts).where(inArray(emergencyContacts.userId, ids)).orderBy(asc(emergencyContacts.priority), asc(emergencyContacts.name));
}

export async function getContact(userId: number, id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const ids = await getAccessibleUserIds(userId);
  const result = await db.select().from(emergencyContacts).where(and(eq(emergencyContacts.id, id), inArray(emergencyContacts.userId, ids))).limit(1);
  return result[0];
}

export async function listAlerts(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const ids = await getAccessibleUserIds(userId);
  return db.select().from(alertEvents).where(inArray(alertEvents.userId, ids)).orderBy(desc(alertEvents.createdAt));
}
